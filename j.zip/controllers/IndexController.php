<?php
namespace app\controllers;

//引入自定义控制器
use app\controllers\CommonController;

class IndexController extends CommonController
{
    public function actionIndex()
    {
//        echo 'index/index';
        //views/index/index.php
//      去掉自带样式
//        $this->layout=false;
//        $model = new Test;
//        $data = $model->find()->one();
//        return $this->render('index', ['row' => $data]);
//        return $this->renderPartial('index');
        $this->layout = 'layout1';
        return $this->render('index');
    }
}