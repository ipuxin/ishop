<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=u119591_imshop',
    'username' => 'u119591',
    'password' => 'KMko5x9f',
    'charset' => 'utf8',
    'tablePrefix'=>'shop_',
];
