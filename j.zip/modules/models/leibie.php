array(21) {
    [0]=>
  array(4) {
        ["cateid"]=>
    string(1) "1"
        ["title"]=>
    string(12) "0 |---衣服"
        ["parentid"]=>
    string(1) "0"
        ["createtime"]=>
    int(0)
  }
  [1]=>
  array(4) {
        ["cateid"]=>
    string(1) "4"
        ["title"]=>
    string(16) "1 |---|---裙子"
        ["parentid"]=>
    string(1) "1"
        ["createtime"]=>
    int(0)
  }
  [2]=>
  array(4) {
        ["cateid"]=>
    string(1) "7"
        ["title"]=>
    string(23) "2 |---|---|---超短裙"
        ["parentid"]=>
    string(1) "4"
        ["createtime"]=>
    int(0)
  }
  [3]=>
  array(4) {
        ["cateid"]=>
    string(2) "22"
        ["title"]=>
    string(30) "3 |---|---|---|---超超短裙"
        ["parentid"]=>
    string(1) "7"
        ["createtime"]=>
    int(1470376216)
  }
  [4]=>
  array(4) {
        ["cateid"]=>
    string(2) "24"
        ["title"]=>
    string(34) "4 |---|---|---|---|---超超短裙"
        ["parentid"]=>
    string(2) "22"
        ["createtime"]=>
    int(1470376226)
  }
  [5]=>
  array(4) {
        ["cateid"]=>
    string(2) "28"
        ["title"]=>
    string(32) "5 |---|---|---|---|---|---最短"
        ["parentid"]=>
    string(2) "24"
        ["createtime"]=>
    int(1470376750)
  }
  [6]=>
  array(4) {
        ["cateid"]=>
    string(2) "31"
        ["title"]=>
    string(33) "6 |---|---|---|---|---|---|---啊"
        ["parentid"]=>
    string(2) "28"
        ["createtime"]=>
    int(1470376921)
  }
  [7]=>
  array(4) {
        ["cateid"]=>
    string(2) "32"
        ["title"]=>
    string(36) "7 |---|---|---|---|---|---|---最最"
        ["parentid"]=>
    string(2) "28"
        ["createtime"]=>
    int(1470377964)
  }
  [8]=>
  array(4) {
        ["cateid"]=>
    string(2) "29"
        ["title"]=>
    string(32) "8 |---|---|---|---|---|---最短"
        ["parentid"]=>
    string(2) "24"
        ["createtime"]=>
    int(1470376763)
  }
  [9]=>
  array(4) {
        ["cateid"]=>
    string(2) "30"
        ["title"]=>
    string(38) "9 |---|---|---|---|---|---超超短裙"
        ["parentid"]=>
    string(2) "24"
        ["createtime"]=>
    int(1470376827)
  }
  [10]=>
  array(4) {
        ["cateid"]=>
    string(2) "26"
        ["title"]=>
    string(35) "10 |---|---|---|---|---超超短裙"
        ["parentid"]=>
    string(2) "22"
        ["createtime"]=>
    int(1470376733)
  }
  [11]=>
  array(4) {
        ["cateid"]=>
    string(2) "27"
        ["title"]=>
    string(35) "11 |---|---|---|---|---超超短裙"
        ["parentid"]=>
    string(2) "22"
        ["createtime"]=>
    int(1470376739)
  }
  [12]=>
  array(4) {
        ["cateid"]=>
    string(2) "23"
        ["title"]=>
    string(31) "12 |---|---|---|---超超短裙"
        ["parentid"]=>
    string(1) "7"
        ["createtime"]=>
    int(1470376219)
  }
  [13]=>
  array(4) {
        ["cateid"]=>
    string(1) "5"
        ["title"]=>
    string(17) "13 |---|---裤子"
        ["parentid"]=>
    string(1) "1"
        ["createtime"]=>
    int(0)
  }
  [14]=>
  array(4) {
        ["cateid"]=>
    string(2) "33"
        ["title"]=>
    string(21) "14 |---|---|---长裤"
        ["parentid"]=>
    string(1) "5"
        ["createtime"]=>
    int(1470380520)
  }
  [15]=>
  array(4) {
        ["cateid"]=>
    string(1) "6"
        ["title"]=>
    string(17) "15 |---|---袜子"
        ["parentid"]=>
    string(1) "1"
        ["createtime"]=>
    int(0)
  }
  [16]=>
  array(4) {
        ["cateid"]=>
    string(2) "19"
        ["title"]=>
    string(23) "16 |---|---超超短裙"
        ["parentid"]=>
    string(1) "1"
        ["createtime"]=>
    int(1470376131)
  }
  [17]=>
  array(4) {
        ["cateid"]=>
    string(2) "20"
        ["title"]=>
    string(23) "17 |---|---超超短裙"
        ["parentid"]=>
    string(1) "1"
        ["createtime"]=>
    int(1470376136)
  }
  [18]=>
  array(4) {
        ["cateid"]=>
    string(2) "21"
        ["title"]=>
    string(23) "18 |---|---超超短裙"
        ["parentid"]=>
    string(1) "1"
        ["createtime"]=>
    int(1470376209)
  }
  [19]=>
  array(4) {
        ["cateid"]=>
    string(1) "2"
        ["title"]=>
    string(19) "19 |---电子产品"
        ["parentid"]=>
    string(1) "0"
        ["createtime"]=>
    int(0)
  }
  [20]=>
  array(4) {
        ["cateid"]=>
    string(1) "3"
        ["title"]=>
    string(19) "20 |---日常用品"
        ["parentid"]=>
    string(1) "0"
        ["createtime"]=>
    int(0)
  }
}
