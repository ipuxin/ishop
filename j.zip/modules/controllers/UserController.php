<?php
namespace app\modules\controllers;

use yii\web\Controller;
use app\models\User;
use app\models\Profile;
use Yii;
use yii\data\Pagination;

class UserController extends Controller
{

    //显示用户列表
    public function actionUsers()
    {
        $model=User::find()->joinWith('profile');
        $count = $model->count();
        $pageSize = Yii::$app->params['pageSize']['manage'];
        $pager = new Pagination(['totalCount' => $count, 'pageSize' => $pageSize]);
        $users = $model->offset($pager->offset)->limit($pager->limit)->all();

        $this->layout = 'layout1';
        return $this->render('users', ['users' => $users, 'pager' => $pager]);
    }

    //添加用户
    public function actionReg()
    {

        $model = new User;
        //判断如果有post提交,则提交到model层处理
        if (Yii::$app->request->isPost) {
            $post = Yii::$app->request->post();

            //如果reg方法返回真, 则表明添加成功
            if ($model->reg($post)) {
                Yii::$app->session->setFlash('info', '添加成功');
            } else {
                Yii::$app->session->setFlash('info', '添加失败');
            }
        }
        $model->userpass = '';
        $model->repass = '';

        $this->layout = 'layout1';
        return $this->render('reg', ['model' => $model]);
    }

    //删除用户(使用事务)
    public function actionDel(){
        try{
            //用get方法获取用户id
            $userid=(int)Yii::$app->request->get('userid');
            if(empty($userid)){
                throw new \Exception('id 不正确');
            }
            //开启事务
            $trans=Yii::$app->db->beginTransaction();
            //先删除从表,如果成功再删除主表
            if($obj=Profile::find()->where('userid=:id',[':id'=>$userid])->one()){
                $res = Profile::deleteAll('userid=:id',[':id'=>$userid]);
                if(empty($res)){
                    throw new \Exception('删除从表失败');
                }
            }
            //删除主表
            if(!User::deleteAll('userid=:id',[':id'=>$userid])){
                throw new \Exception('删除主表失败');
            }
            //以上操作都没问题,提交执行
            $trans->commit();
        }catch (\Exception $e){
            //出现异常回滚
            if(Yii::$app->db->getTransaction()){
                $trans->rollBack();
                $message= $e->getMessage();
                Yii::$app->session->setFlash('info',$message);
            }
        }
        $this->redirect(['user/users']);
    }

}
