<?php

namespace app\modules;

class admin extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
