<?php
//用户详细信息表
namespace app\models;

use yii\db\ActiveRecord;

class Profile extends ActiveRecord{
    public static function tableName(){
        return '{{%profile}}';
    }
}